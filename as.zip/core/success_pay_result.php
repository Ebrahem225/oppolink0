<?php 
if(!defined('SUCCESSPAY')){
echo ('Выявлена попытка взлома!');
exit();
}

$referer=$db->getOne("SELECT curator FROM `ss_users` WHERE id=?i", $id);
$db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime) VALUES(?i,?i,?s,?s)", $id, $referer, $sum, time());	

/*АКЦИЯ*/
if($bonus_act==1){
	//Проверяем сумму
	if($sum>=$bonus_minsum){
		
		//Платим манибек
		$peyeerwallet=strtoupper($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i", $id));
		$psum=$sum*($bonus_percent/100);
		if($id>0 && $peyeerwallet[0]=='P'){
		whithdraw($id,$peyeerwallet,$psum);		
		addUserStat($id, "Выплата бонусных", "".$psum."");
		//Добавляем инфу о выплате в БД
		$db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime, status) VALUES(?i,?i,?s,?s,?i)", $id, 0, $psum, time(), 1);
		}
				
	}	
}

if($refrezhim==1){
//Платим рефские
$refererwallet=strtoupper($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i", $referer));
$referersum=$sum*($refpercent/100);
if($referer>0 && $refererwallet[0]=='P'){
whithdraw($referer,$refererwallet,$referersum);		
addUserStat($referer, "Выплата реферальных", "".$referersum."");
//Добавляем инфу о выплате в БД
$db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime, status) VALUES(?i,?i,?s,?s,?i)", $referer, 0, $referersum, time(), 1);
}

}

/*Платим админские*/
$adminid=$db->getOne("SELECT id FROM `ss_users` WHERE wallet=?s", $koshelek_admina);
//if($adminid>0){
$adminsum=$sum*($admpercent/100);
addUserStat($adminid, "Выплата админских", "".$adminsum."");
whithdraw($adminid,$koshelek_admina,$adminsum);	
//}

?>
<?/*-------------------*//*
Web-site: ed-script.pro
*//*-------------------*/?>