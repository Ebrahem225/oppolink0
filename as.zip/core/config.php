<?php

/*
ВАЖНО!
Админ должен быть с ID=1 (Зарегистрирован на проекте первым)
*/

if(!defined('SCRIPT_BY_SIRGOFFAN')){

echo ('Выявлена попытка взлома!');
exit();
}

$bd_host = "localhost";//В основном стоит по умолчанию
$bd_user = "root"; // Пользователь базы данных
$bd_password = "";  // Пароль от базы данных
$bd_base = "haip"; // Имя базы данных

$db = new SafeMySQL(array('user' => $bd_user, 'pass' => $bd_password, 'db' => $bd_base, 'charset' => 'utf8'));

// Получение настроек
$tarif_settings_get = $db->fetch($db->query("SELECT * FROM tarif"));
if (empty($tarif_settings_get)) die('Ошибка при получении настроек.');

//ПРОВЕРКА СУЩЕСТВОВАНИЯ КОШЕЛЬКА PAYEER ПРИ РЕГИСТРАЦИИ
$c_payyer_walletreg = 0; //1 - включено, 0 - отключено

//НАСТРОЙКА ПРОЕКТА
$ssl_connect="https";//Ваше соединение http или https (Для реф ссылок и баннера)
$itworks=1; //Режим работы сайта. 1 - сайт работает, 0 - регистрация закрыта
$sitename="DEMO #63"; //Название проекта
$timeprofit="24 часа"; //Время вклада в часах для шапки и faq
$banner_468="/boots1.gif"; //Ссылка на баннер проекта 468x60
$banner_728="/boots2.gif"; //Ссылка на баннер проекта 720x90
$koshelek_admina=''; //Кошелек для админских выплат

//ПРИЕМ СРЕДСТВ (мерчант):
$m_shop = ''; //ID магазина в системе Payeer
$m_desc = 'Открытие вклада '.$sitename; //Текст комментария к платежу
$m_key = ''; //Ключ от магазина

//ВЫПЛАТА (api):
$accountNumber = '';  //Счет, с которого будут происходить выплаты
$apiId = ''; //ID API
$apiKey = ''; //Секретный ключ API
$m_curr='RUB'; //Валюта проекта

//МАРКЕТИНГ ПРОЕКТА
$mindep=$tarif_settings_get['mindep']; //Минимальный размер депозита
$maxdep=$tarif_settings_get['maxdep']; //Максимальный размер депозита
$refpercent=$tarif_settings_get['refpercent']; //Реф. процент
$admpercent=0; //Админский процент
$depperiod=500000; //Время вклада (В минутах)
$deppercentage=$tarif_settings_get['deppercentage']; //Процентаж (+ сколько к сумме депа)
$refrezhim=1; //Режим выплаты реферальных: 1 - в момент депа рефералом, 2 - в момент окончания срока депа реферала

//ВОЗВРАТ ПО АКЦИИ
$bonus_act = 0; //Режим акции. 1 - акция активна, 0 - отключена
$bonus_minsum=10; //Минимальный вклад, при котором активируется возврат по акции
$bonus_percent=20; //Процентаж, сколько процентов ворачивается
/*Как работает акция.*/
//Допустим, $bonus_minsum=1000, а $bonus_percent=10. Это значит, что при вкладе пользователем на сумму превышающую 1000 рублей, ему незамедлительно ворачивается 10%

//НАСТРОЙКИ НЕ МЕНЯТЬ, НА БЕЗОПАСНОСТЬ СКРИПТА НЕ ВЛИЯЮТ
$adminadress="admin";
$admintoken="wgwgwsbvgsd7weshvf7sevgfs";
$admintoken=md5($admintoken.@date("d.m.Y"));
$use_kapcha=0;
$http_s="http";
$nocron=0;

/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

//Web-site: ed-script.pro
?>