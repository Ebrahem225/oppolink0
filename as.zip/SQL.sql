-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 06 2019 г., 16:28
-- Версия сервера: 5.6.41
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `stats`
--

-- --------------------------------------------------------

--
-- Структура таблицы `batches`
--

CREATE TABLE `batches` (
  `id` int(11) NOT NULL,
  `batchpm` varchar(55) NOT NULL,
  `m_operation_id` varchar(55) NOT NULL,
  `vremya` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `summa` float NOT NULL,
  `segodnya` varchar(12) NOT NULL,
  `frod` int(1) NOT NULL DEFAULT '0',
  `summa_rub` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `deposits`
--

CREATE TABLE `deposits` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `curatorid` int(11) NOT NULL,
  `summa` double(10,2) NOT NULL,
  `unixtime` bigint(20) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `summa` float NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `comment` text CHARACTER SET utf8 NOT NULL,
  `type` int(11) NOT NULL COMMENT '0 - нейтрально (отладка), 1 - положительное действие (green), 2 - отрицательное (red)',
  `status` int(1) NOT NULL DEFAULT '0',
  `timeunix` int(22) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `more`
--

CREATE TABLE `more` (
  `start` text,
  `feikuser` text,
  `vk` text,
  `telega` text,
  `mail` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `more`
--

INSERT INTO `more` (`start`, `feikuser`, `vk`, `telega`, `mail`) VALUES
('01.01.2019', '0', 'https://vk.com', 'https://t.me', 'support@mail');

-- --------------------------------------------------------

--
-- Структура таблицы `ss_users`
--

CREATE TABLE `ss_users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `wallet` varchar(15) NOT NULL,
  `wallet_password` varchar(64) NOT NULL,
  `curator` int(11) NOT NULL,
  `i_have_refs_as_curator` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL COMMENT 'IP пользователя при регистрации',
  `last_ip` varchar(15) NOT NULL COMMENT 'IP пользователя при последнем входе в аккаунт',
  `came` varchar(50) NOT NULL COMMENT 'Откуда пришел',
  `act_1` int(1) NOT NULL DEFAULT '0',
  `reg_unix` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Таблица юзеров';

--
-- Дамп данных таблицы `ss_users`
--

INSERT INTO `ss_users` (`id`, `email`, `wallet`, `wallet_password`, `curator`, `i_have_refs_as_curator`, `ip`, `last_ip`, `came`, `act_1`, `reg_unix`) VALUES
(1, 'admin@local', 'P00000000', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(2, 'feik1@local', 'P13611***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(3, 'feik2@local', 'P11518***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(4, 'feik3@local', 'P82770***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(5, 'feik4@local', 'P80276***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(6, 'feik5@local', 'P73716***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(7, 'feik6@local', 'P28523***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(8, 'feik7@local', 'P96326***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(9, 'feik8@local', 'P65174***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(10, 'feik9@local', 'P39222***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(11, 'feik10@local', 'P84451***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(12, 'feik11@local', 'P24068***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(13, 'feik12@local', 'P95171***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(14, 'feik13@local', 'P54756***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(15, 'feik14@local', 'P84689***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(16, 'feik15@local', 'P11904***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(17, 'feik16@local', 'P59577***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(18, 'feik17@local', 'P54614***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(19, 'feik18@local', 'P95644***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(20, 'feik19@local', 'P14987***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(21, 'feik20@local', 'P77754***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(22, 'feik21@local', 'P55301***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(23, 'feik22@local', 'P56532***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(24, 'feik23@local', 'P55656***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(25, 'feik24@local', 'P24426***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(26, 'feik25@local', 'P34068***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(27, 'feik26@local', 'P96851***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(28, 'feik27@local', 'P22201***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(29, 'feik28@local', 'P15588***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946),
(30, 'feik29@local', 'P39504***', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 1, 0, '127.0.0.1', '127.0.0.1', 'no link', 0, 1540299946);

-- --------------------------------------------------------

--
-- Структура таблицы `tarif`
--

CREATE TABLE `tarif` (
  `mindep` double(10,2) NOT NULL DEFAULT '0.00',
  `maxdep` double(10,2) NOT NULL DEFAULT '0.00',
  `refpercent` int(244) NOT NULL DEFAULT '0',
  `deppercentage` int(244) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tarif`
--

INSERT INTO `tarif` (`mindep`, `maxdep`, `refpercent`, `deppercentage`) VALUES
(50.00, 5000.00, 10, 50);

-- --------------------------------------------------------

--
-- Структура таблицы `userstat`
--

CREATE TABLE `userstat` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `type` varchar(100) CHARACTER SET utf8 NOT NULL,
  `opisanie` text CHARACTER SET utf8 NOT NULL,
  `color` varchar(50) CHARACTER SET utf8 NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `summa` float DEFAULT NULL,
  `comment` varchar(33) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `batches`
--
ALTER TABLE `batches`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `ss_users`
--
ALTER TABLE `ss_users`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `ss_users` ADD FULLTEXT KEY `came` (`came`);

--
-- Индексы таблицы `userstat`
--
ALTER TABLE `userstat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `batches`
--
ALTER TABLE `batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `ss_users`
--
ALTER TABLE `ss_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT для таблицы `userstat`
--
ALTER TABLE `userstat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
