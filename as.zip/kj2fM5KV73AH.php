<?php
require_once('./core/classes/cpayeer.php');
$accountNumber = '';
$apiId = '';
$apiKey = '';
$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
if ($payeer->isAuth())
{
	$arBalance = $payeer->getBalance();
	echo '<div style="width: 500px;font-size: 50px;"><b>Пеер: '.$arBalance[balance][RUB][DOSTUPNO].' руб </b></div>';
}
else
{
	echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
}
?>