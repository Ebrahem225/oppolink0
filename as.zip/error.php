<?
define ("SCRIPT_BY_SIRGOFFAN" , dirname(__FILE__) );
if($_GET['key']=='error'){
require_once($_SERVER['DOCUMENT_ROOT']."/core/ini.php");

$db->query("UPDATE deposits SET status = '0' WHERE status = '2'");
}
?>