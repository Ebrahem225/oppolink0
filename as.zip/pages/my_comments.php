<?if($id > (1)){?>

<div class="row clearfix animated bounceInRight">
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
<div class="card" style="min-height: 200px;">
<div class="header">
<h2><i class="fas fa-comments"></i> Ресурсы для отзывов</h2>
</div>
<div class="body table-responsive">
<center>
<div class="soc">
<a href="<?=$vkgrup?>" target="_blank"><i class="fab fa-vk" style="font-size:100px;padding-right: 5px;"></i></a>
<a href="<?=$telega?>" target="_blank"><i class="fab fa-telegram-plane" style="font-size:100px;padding-left: 5px;"></i></a>
</div>
</center>
</div>
</div>
</div>

<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
<div class="card" style="min-height: 200px;">
<div class="header">
<h2><i class="fab fa-wpforms"></i> Очень просим</h2>
</div>
<div class="body table-responsive">

<p style="font-weight: normal;">
Если Вы получаете выплаты с нашего проекта <b><?=$sitename?></b> то мы будем вам очень благодарны за любой оставленный отзыв на предсталенных ресурсах.
</p>

</div>
</div>
</div>
</div>

<?}else{?>
<?if($id == (1)){?>
<script type="text/javascript">
window.location.href = '/?page=admin_deposits';
</script>
<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}}?>