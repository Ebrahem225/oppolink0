<?if(empty($id)){?>



<?}else{?>
<script type="text/javascript">
window.location.href = '/newdep';
</script>
<?}?>