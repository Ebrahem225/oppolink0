<?if($id == (1)){?>

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2>Здесь отображаются все выплаты из проекта</h2>
</div>
<div class="body table-responsive">
<p style="margin-bottom: -11px;">

<center>
<p style="color:red;"><b>У вас есть 29 фейков для имитации выплат.<br>Их личные номера ID от 2 до 30</b></p>
<?if (isset($_POST['viplata_id']) && isset($_POST['viplata_sum'])){

$db->query(" INSERT INTO userstat (`id`, `userid`, `type`, `opisanie`, `color`, `data`, `summa`, `comment`) VALUES (NULL, '".$_POST['viplata_id']."', 'Выплата по депозиту', '".$_POST['viplata_sum']."', 'black', CURRENT_TIMESTAMP, '0', '') ");
header("Location: /?page=admin_withdrawal");
if ($db) {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="text" name="viplata_id" placeholder="ID фейка">
<input type="text" name="viplata_sum" placeholder="Сумма выплаты">
<button type="submit" name="submit">Создать выплату</button>
</form>
</center>
</p>
<table class="table table-striped table-borderless m-b-5">
<thead>
<tr>
<th style="width:20%;">Дата</th>
<th class="width:20%">Операция</th>
<th style="width:20%;">Кошелек</th>
<th style="width:20%;">Сумма</th>
<th style="width:20%;">Статус</th>
</tr>
</thead>
<tbody class="no-border-x">
<? 
$depositsrow=$db->query("SELECT * FROM `userstat` WHERE type='Выплата реферальных' OR type='Выплата по депозиту' OR type='Выплата админских' ORDER BY id DESC LIMIT 1000");
while($deposits=$db->fetch($depositsrow)){?>
<?$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0); ?>
<tr>
<td><?=$deposits['data']?></td>
<td><?=$deposits['type']?></td>
<td><?=$wallet?></td>
<td><?=$deposits['opisanie']?> <b><?=$m_curr?></b></td>
<td><b>Выплачено</b></td>
</tr>
<?}?>
</tbody>
</table>
</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}?>