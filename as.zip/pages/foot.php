<?if(!empty($_error)){?><center><div class="stat" style="position: fixed;display: inline-block;font-size: 16px;color: rgb(250, 250, 250);z-index: 10;right: 17px;top: 100px;box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 3px;border: 1px solid rgba(255, 255, 255, 0);width: 330px;background: rgba(4,35,50,0.45);height: 140px;border-radius: 4px;line-height: 3.42857143;"><div style="color: rgb(255, 255, 255); font-size: 16px; height: 30px; padding: 0px;">Сообщение</div><font><?=$_error?></font></div></center><?}?>
<?if(!empty($_success)){?><center><div class="stat" style="position: fixed;display: inline-block;font-size: 16px;color: rgb(250, 250, 250);z-index: 10;right: 17px;top: 100px;box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 3px;border: 1px solid rgba(255, 255, 255, 0);width: 330px;background: rgba(4,35,50,0.45);height: 140px;border-radius: 4px;line-height: 3.42857143;"><div style="color: rgb(255, 255, 255); font-size: 16px; height: 30px; padding: 0px;">Сообщение</div><font><?=$_success?></font></div></center><?}?>

<?if($id == (1)){?>

<div class="row clearfix">
<div class="col-md-12">
<div class="card">
<div class="body">
<p class="copy m-b-0" style="text-align: center;">Project created by <a href="https://ed-script.pro" target="_blank"><u><span>Ed-script</span></u></a></p>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- Jquery Core Js --> 
<script src="/style/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 
<script src="/style/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 

<script src="/style/bundles/jvectormap.bundle.js"></script> <!-- JVectorMap Plugin Js -->
<script src="/style/bundles/sparkline.bundle.js"></script> <!-- Sparkline Plugin Js -->
<script src="/style/bundles/morrisscripts.bundle.js"></script><!-- Morris Plugin Js -->
<script src="/style/bundles/flotscripts.bundle.js"></script><!-- Flot Charts Plugin Js -->

<script src="/style/bundles/mainscripts.bundle.js"></script>
<script src="/style/js/pages/index.js"></script>
<center><a href="https://php-scripts.ru" target="_blank"><img src="https://php-scripts.ru/wp-content/uploads/2019/02/quote-logo.png" width="72px" height="32px" alt="Скрипты хайпов" title="скачать"></a></center>
</body>
</html>

<?}else{?>
<?if($id > (1)){?>

<div class="row clearfix animated bounceInUp">
<div class="col-md-12">
<div class="card">
<div class="body">
<p class="copy m-b-0">
<font style="">Инвестиционный проект <?=$sitename?></font> <span style="float: right;font-size: 10px;"><a href="https://ed-script.pro" target="_blank" title="Заказать проект">ed-script</a></span>
</p>

</div>
</div>
</div>
</div>
</div>
</section>
<!-- Jquery Core Js --> 
<script src="/style/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 
<script src="/style/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 

<script src="/style/bundles/jvectormap.bundle.js"></script> <!-- JVectorMap Plugin Js -->
<script src="/style/bundles/sparkline.bundle.js"></script> <!-- Sparkline Plugin Js -->
<script src="/style/bundles/morrisscripts.bundle.js"></script><!-- Morris Plugin Js -->
<script src="/style/bundles/flotscripts.bundle.js"></script><!-- Flot Charts Plugin Js -->

<script src="/style/bundles/mainscripts.bundle.js"></script>
<script src="/style/js/pages/index.js"></script>
</body>
</html>

<?}else{?>

<div id="footer_down">
<div id="sub_down">
<p>Инвестиционный проект - <?=$sitename?>. All Rights Reserved.</p>
</div>
</div>
</div>

</main>
</div>
</body>
</html>

<?}}?>