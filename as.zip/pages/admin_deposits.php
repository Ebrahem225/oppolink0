<?if($id == (1)){?>

<div class="row clearfix">
<div class="col-sm-12 col-md-6">
<div class="card" >
<p style="margin-bottom: 13px;">
<center>
<p><b>Для открытия вклада участнику<br>введите ID участника и нужную сумму</b></p>
<?if (isset($_POST['fek_id']) && isset($_POST['fek_sum']) && isset($_POST['fek_tim'])){

$db->query(" INSERT INTO deposits (`id`, `userid`, `curatorid`, `summa`, `unixtime`, `status`) VALUES (NULL, '".$_POST['fek_id']."', '1', '".$_POST['fek_sum']."', '".$_POST['fek_tim']."', '0') ");
header("Location: /?page=admin_deposits");
if ($db) {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="text" name="fek_id" placeholder="ID участника">
<input type="text" name="fek_sum" placeholder="Сумма вклада">
<input type="hidden" name="fek_tim" value="<?=time();?>">
<button onclick="return proverka();" type="submit" name="submit" style="margin-top: 5px;">Открыть вклад</button>
<script>
function proverka() {
    if (confirm("Подтвердить")) {
        return true;
    } else {
        return false;
    }
}
</script>
</form>
</center>
</p>
</div>
</div>

<div class="col-sm-12 col-md-6">
<div class="card" >
<p style="margin-bottom: 13px;">
<center>
<p><b>Для смены суммы вклада участнику<br>введите ID депозита и нужную сумму</b></p>
<?if (isset($_POST['dep_id']) && isset($_POST['new_vklad'])){
$db->query("UPDATE deposits SET summa='".$_POST['new_vklad']."' WHERE id='".$_POST['dep_id']."' ");
header("Location: /?page=admin_deposits");
if ($db) {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="text" name="dep_id" placeholder="ID депозита">
<input type="text" name="new_vklad" placeholder="Сумма вклада">
<button type="submit" name="submit" style="margin-top: 5px;">Изменить вклад</button>
</form>
</center>
</p>
</div>
</div>
</div>

<!-- time blok -->
<div class="row clearfix">
<div class="col-sm-12 col-md-6">
<div class="card" >
<p style="margin-bottom: 13px;">
<center>
<p><b>Удаление депозита!<br>Для удаления депозита, введите ID депозита</b></p>
<?if (isset($_POST['del_dep'])){
$db->query("DELETE FROM deposits WHERE id='".$_POST['del_dep']."' ");
header("Location: /?page=admin_deposits");
if ($db) {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="text" name="del_dep" placeholder="Введите ID депозита"><br>
<button type="submit" name="submit" style="margin-top: 5px;">Удалить вклад</button>
</form>
</center>
</p>
</div>
</div>

<div class="col-sm-12 col-md-6">
<div class="card" >
<p style="margin-bottom: 13px;">
<center>
<p style="color:red;"><b>У вас есть 29 фейков для имитации пополнений.<br>Их личные номера ID от 2 до 30</b></p>
<?if (isset($_POST['f_id']) && isset($_POST['f_dep']) && isset($_POST['f_tim'])){

$db->query(" INSERT INTO `log` (`id`, `userid`, `summa`, `description`, `comment`, `type`, `status`, `timeunix`) VALUES (NULL, '".$_POST['f_id']."', '".$_POST['f_dep']."', 'Успешно', 'Пополнение баланса', '1', '0', '".$_POST['f_tim']."') ");
header("Location: /?page=admin_deposits");
if ($db) {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<input type="text" name="f_id" placeholder="ID фейка">
<input type="text" name="f_dep" placeholder="Сумма вклада">
<input type="hidden" name="f_tim" value="<?=time();?>">
<button type="submit" name="submit" style="margin-top: 5px;">Создать вклад</button>
</form>
</center>
</p>
</div>
</div>
</div>
<!-- time blok -->

<div class="row clearfix">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2>Здесь отображаются все работающие депозиты</h2>
</div>
<div class="body table-responsive">
<table class="table table-striped table-borderless m-b-5">
<thead>
<tr>
<th style="width:16%;">Дата</th>
<th class="width:16%">ID Депозита</th>
<th style="width:16%;">Кошелек</th>
<th style="width:16%;">Сумма</th>
<th style="width:16%;">Осталось</th>
<th style="width:16%;">На вывод</th>
</tr>
</thead>
<tbody class="no-border-x">
<? 
$checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE status='0' LIMIT 1");
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM `deposits` WHERE status='0' ORDER BY id DESC LIMIT 1000");

while($deposits=$db->fetch($depositsrow)){?>
<?$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0); ?>
<?$psumma=$deposits['summa']+($deposits['summa']*($deppercentage/100));?>
<tr>
<td><?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
<td>ID > <?=$deposits['id']?></td>
<td><?=$wallet?></td>
<td><?=$deposits['summa']?> <b><?=$m_curr?></b></td>
<?//-(60*($depperiod)) - длительность депа в секундах
$seconds = time()-$deposits['unixtime']; //Секунд прошло с момента депа

$seconds=(60*($depperiod))-$seconds; //Длительность депа, минус прошло = осталось
//echo "<br>".date('H:i:s',time());
//echo "<br>".date('H:i:s',$deposits['unixtime'])."<br>".$seconds;
if($seconds<1){
if($deposits['status']==1){
$deptime="Выплачено";}else{
$deptime="В обработке";
}
}else{

$hours = floor($seconds/3600);
$seconds = $seconds-($hours*3600);
$minutes = floor($seconds/60);
$seconds = $seconds-($minutes*60);
$seconds = floor($seconds);

$h=$hours;
if($h<10){$h='0'.$h;}
$m=$minutes;
if($m<10){$m='0'.$m;}
$s=$seconds;
if($s<10){$s='0'.$s;}
$deptime=$h.":".$m.":".$s;
}
?>
<td class="countdown" align="center"><?=$deptime;?></td>
<td><?=$psumma?> <b><?=$m_curr?></b></td>
</tr>
<?}}?>
</tbody>
</table>
</div>
</div>
</div>
</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}?>