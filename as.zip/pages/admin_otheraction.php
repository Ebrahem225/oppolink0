<?if($id == (1)){?>

<div class="row clearfix">

<div class="col-lg-6 col-md-6 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<p style="margin-bottom: 13px;">
<center>

<p><b>Установка % ставки по депозиту!</b></p>
<?if (isset($_POST['deppercentage'])){
$db->query("UPDATE tarif SET deppercentage='".$_POST['deppercentage']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$deppercentage;?>%</b></font></p>
<input type="text" name="deppercentage" placeholder="Ввести значение">
<button type="submit" name="submit">Установить</button>
</form>

<hr>
<p><b>Установка % партнерского отчисления!</b></p>
<?if (isset($_POST['refpercent'])){
$db->query("UPDATE tarif SET refpercent='".$_POST['refpercent']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$refpercent;?>%</b></font></p>
<input type="text" name="refpercent" placeholder="Ввести значение">
<button type="submit" name="submit">Установить</button>
</form>

</center>
</p>
</div>
</div>
</div>
</div>
</div>



<div class="col-lg-6 col-md-6 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<p style="margin-bottom: 13px;">
<center>

<p><b>Установка минимальной суммы!</b></p>
<?if (isset($_POST['mindep'])){
$db->query("UPDATE tarif SET mindep='".$_POST['mindep']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$mindep;?> <?=$m_curr?></b></font></p>
<input type="text" name="mindep" placeholder="Ввести значение">
<button type="submit" name="submit">Установить</button>
</form>

<hr>
<p><b>Установка максимальной суммы!</b></p>
<?if (isset($_POST['maxdep'])){
$db->query("UPDATE tarif SET maxdep='".$_POST['maxdep']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$maxdep;?> <?=$m_curr?></b></font></p>
<input type="text" name="maxdep" placeholder="Ввести значение">
<button type="submit" name="submit">Установить</button>
</form>

</center>
</p>
</div>
</div>
</div>
</div>
</div>

</div>

<div class="row clearfix">

<div class="col-lg-6 col-md-6 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<p style="margin-bottom: 13px;">
<center>
<p><b>Установка даты старта проекта!</b></p>
<?if (isset($_POST['data_start'])){
$db->query("UPDATE more SET start='".$_POST['data_start']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$data_starta?></b></font></p>
<input type="text" name="data_start" placeholder="Дата старта">
<button type="submit" name="submit">Установить</button>
</form>
</center>
</p>
</div>
</div>
</div>
</div>
</div>

<div class="col-lg-6 col-md-6 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<p style="margin-bottom: 13px;">
<center>
<p><b>Установка почты администратора!</b></p>
<?if (isset($_POST['mail'])){
$db->query("UPDATE more SET mail='".$_POST['mail']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$adminmail?></b></font></p>
<input type="text" name="mail" placeholder="Почта проекта">
<button type="submit" name="submit">Установить</button>
</form>
</center>
</p>
</div>
</div>
</div>
</div>
</div>

</div>


<div class="row clearfix">

<div class="col-lg-6 col-md-6 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<p style="margin-bottom: 13px;">
<center>
<p><b>Установка ссылки на Вконтакте!</b></p>
<?if (isset($_POST['vk'])){
$db->query("UPDATE more SET vk='".$_POST['vk']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$vkgrup?></b></font></p>
<input type="text" name="vk" placeholder="Ссылка на Вконтакте">
<button type="submit" name="submit">Установить</button>
</form>
</center>
</p>
</div>
</div>
</div>
</div>
</div>

<div class="col-lg-6 col-md-6 col-sm-12">
<div class="card widget-stat">
<div class="body">
<div class="media">
<div class="media-text">
<p style="margin-bottom: 13px;">
<center>
<p><b>Установка ссылки на Телеграм!</b></p>
<?if (isset($_POST['telega'])){
$db->query("UPDATE more SET telega='".$_POST['telega']."' ");
header("Location: /?page=admin_otheraction");
if ($db = 'true') {
        echo "Данные успешно обновлены.";
    } else {
        echo "Произошла ошибка.";
    }
}
?>
<form action="" method="POST">
<p style="text-align: center;">На данный момент установлена - <font color="red"><b><?=$telega?></b></font></p>
<input type="text" name="telega" placeholder="Ссылка на Телеграм">
<button type="submit" name="submit">Установить</button>
</form>
</center>
</p>
</div>
</div>
</div>
</div>
</div>

</div>

<?}else{?>
<script type="text/javascript">
window.location.href = '/';
</script>
<?}?>