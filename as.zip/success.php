<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Ваш баланс пополнен - <?=$_SERVER['SERVER_NAME'];?></title>
<meta http-equiv="refresh" content="5; url=https://<?=$_SERVER['SERVER_NAME'];?>/deposits">
<style>
@import url('https://fonts.googleapis.com/css?family=Roboto');
    body{background: green; color: #fff; font-family: 'Roboto', sans-serif;}
</style>
</head>
<body>
<br/>
<br/>
<br/>
<br/>
<center>Оплата депозита прошла УСПЕШНО!</center>
<center>Ожидайте перенаправления...</center>
</body>
</html>